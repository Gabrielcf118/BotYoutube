#!/bin/bash

zip -r "botYoutube.zip" * -x "botYoutube.zip"